import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

class UserDAOTest {

    private UserDAOTest userDAOTest;

    private Connection mockConnection;
    private PreparedStatement mockStatement;
    private ResultSet mockResultSet;
    private MockedStatic<ConnectionFactory> mockedFactoryClass;
    private ConnectionFactory mockFactory;

    @BeforeEach
    void setUp() throws SQLException {
        accountService = new AccountService();

        mockConnection = Mockito.mock(Connection.class);
        mockStatement = Mockito.mock(PreparedStatement.class);
        mockResultSet = Mockito.mock(ResultSet.class);
        mockFactory = Mockito.mock(ConnectionFactory.class);

        mockedFactoryClass = mockStatic(ConnectionFactory.class);
        mockedFactoryClass.when(ConnectionFactory::getConnectionFactory).thenReturn(mockFactory);

        when(mockFactory.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
    }

    @AfterEach
    void tearDown() {
        mockedFactoryClass.close();
    }

    @Test
    void checkBalance_validAccountAndPin_returnsBalance() throws SQLException {
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getDouble(1)).thenReturn(1234.56);

        double balance = accountService.checkBalance("acc-123", "4321");

        assertEquals(1234.56, balance, 0.0001);
    }

    @Test
    void checkBalance_invalidAccountOrPin_returnsZero() throws SQLException {
        // Arrange: no matching row found
        when(mockResultSet.next()).thenReturn(false);

        // Act
        double balance = accountService.checkBalance("bad-account", "0000");

        // Assert
        assertEquals(0.0, balance, 0.0001);
    }

    @Test
    void checkBalance_sqlException_throwsRuntimeException() throws SQLException {
        // Arrange
        when(mockStatement.executeQuery()).thenThrow(new SQLException("connection lost"));

        // Act + Assert
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> accountService.checkBalance("acc-123", "4321"));
        assertEquals("connection lost", ex.getMessage());
    }
}