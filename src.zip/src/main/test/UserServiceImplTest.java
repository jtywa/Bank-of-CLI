import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.assertions.*;

public class UserServiceImplTest {

    @Test
    void loginPositive(){

    }

    @Test
    void loginNegative(){

    }

    @Test
    void logoutPositive(){

    }

    @Test
    void logoutNegative(){

    }

    @Test
    void addUserPositive(){

    }

    @Test
    void addUserNegative(){

    }

    @Test
    void checkBalancePositive(){

    }

    @Test
    void checkBalanceNegative(){

    }

    @Test
    void depositPositive(){

    }

    @Test
    void depositNegative(){

    }

    @Test
    void withdrawPositive(){

    }

    @Test
    void withdrawNegative(){

    }

    @Test
    void transferPositive(){

    }

    @Test
    void transferNegative(){

    }

    @Test
    void historyPositive(){

    }
    
    @Test
    void historyNegative(){

    }
}
